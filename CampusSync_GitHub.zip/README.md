# CampusSync
Smart Attendance & Campus Coordination (Tecno Verse) — IBM Datathon 2025
